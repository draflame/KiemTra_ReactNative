import { Text, SafeAreaView, StyleSheet, View,TouchableOpacity } from 'react-native';
import {useState} from 'react'
// You can import supported modules from npm
import { Card } from 'react-native-paper';

// or any files within the Snack
import AssetExample from './components/AssetExample';
import ButtonCustom from './components/ButtonCustom'
export default function App() {
  const [value, setValue]= useState(0)
  const [num1, setNum1]= useState(0)
  const [num2, setNum2]= useState(0)
  const [operator, setOp]= useState("")
  
  const Cancel=()=>{
    setOp("")
    setNum1(0)
    setNum2(0)
    setValue(0)
  }
  const Compute=()=>{
    switch(operator){
      case "+":{
        setValue(num1+num2)
      }break;
      case "-":{
        setValue(num1-num2)
      }break;
      case "*":{
        setValue(num1*num2)
      }break;
      case "/":{
        setValue(num1/num2)
      }break;
      default: Cancel()
    }
  }
  return (
    <SafeAreaView style={styles.container}>
      <View style={{flex: 1}}>
      <Text>Man hinh</Text>
      <View style={{alignItems:"center", justifyContent:"center"}}>
        <Text>Num 1: {num1}</Text>
        <Text>Operator: {operator}</Text>
        <Text>Num 2: {num2}</Text>
        <Text>Value: {value}</Text>
      </View></View>
      <View style={{flex: 1}}>
        <Text>Type num 1:</Text>
        <View style={{flex: 1,flexDirection:"row",flexWrap:"wrap"}}>
          <TouchableOpacity onPress={()=>setNum1(1)} style={{padding: 10, backgroundColor: "#ccc", width:50, alignItems:"center", justifyContent: "center", height:50} }>1</TouchableOpacity>
          <TouchableOpacity onPress={()=>setNum1(2)} style={{padding: 10, backgroundColor: "#ccc", width:50, alignItems:"center", justifyContent: "center", height:50}}>2</TouchableOpacity>
          <TouchableOpacity onPress={()=>setNum1(3)} style={{padding: 10, backgroundColor: "#ccc", width:50, alignItems:"center", justifyContent: "center", height:50}}>3</TouchableOpacity>
          <TouchableOpacity onPress={()=>setNum1(4)} style={{padding: 10, backgroundColor: "#ccc", width:50, alignItems:"center", justifyContent: "center", height:50}}>4</TouchableOpacity>
          <TouchableOpacity onPress={()=>setNum1(5)} style={{padding: 10, backgroundColor: "#ccc", width:50, alignItems:"center", justifyContent: "center", height:50}}>5</TouchableOpacity>
          <TouchableOpacity onPress={()=>setNum1(6)} style={{padding: 10, backgroundColor: "#ccc", width:50, alignItems:"center", justifyContent: "center", height:50}}>6</TouchableOpacity>
          <TouchableOpacity onPress={()=>setNum1(7)} style={{padding: 10, backgroundColor: "#ccc", width:50, alignItems:"center", justifyContent: "center", height:50}}>7</TouchableOpacity>
          <TouchableOpacity onPress={()=>setNum1(8)} style={{padding: 10, backgroundColor: "#ccc", width:50, alignItems:"center", justifyContent: "center", height:50}}>8</TouchableOpacity>
          <TouchableOpacity onPress={()=>setNum1()} style={{padding: 10, backgroundColor: "#ccc", width:50, alignItems:"center", justifyContent: "center", height:50}}>9</TouchableOpacity>
          <TouchableOpacity onPress={()=>setNum1(0)} style={{padding: 10, backgroundColor: "#ccc", width:50, alignItems:"center", justifyContent: "center", height:50}}>0</TouchableOpacity>
        </View>
      </View>
      <View style={{flex: 1}}>
        <Text>Operator:</Text>
        <View style={{flex: 1,flexDirection:"row",flexWrap:"wrap"}}>
          <TouchableOpacity onPress={()=>setOp("+")} style={{padding: 10, backgroundColor: "#ccc", width:50, alignItems:"center", justifyContent: "center", height:50}}>+</TouchableOpacity>
          <TouchableOpacity onPress={()=>setOp("-")} style={{padding: 10, backgroundColor: "#ccc", width:50, alignItems:"center", justifyContent: "center", height:50}}>-</TouchableOpacity>
          <TouchableOpacity onPress={()=>setOp("*")} style={{padding: 10, backgroundColor: "#ccc", width:50, alignItems:"center", justifyContent: "center", height:50}}>*</TouchableOpacity>
          <TouchableOpacity onPress={()=>setOp("/")} style={{padding: 10, backgroundColor: "#ccc", width:50, alignItems:"center", justifyContent: "center", height:50}}>/</TouchableOpacity>
        </View>
      </View>

      <View style={{flex: 1}}>
        <Text>Type num 2:</Text>
        <View style={{flex: 1,flexDirection:"row",flexWrap:"wrap"}}>
          <TouchableOpacity onPress={()=>setNum2(1)} style={{padding: 10, backgroundColor: "#ccc", width:50, alignItems:"center", justifyContent: "center", height:50} }>1</TouchableOpacity>
          <TouchableOpacity onPress={()=>setNum2(2)} style={{padding: 10, backgroundColor: "#ccc", width:50, alignItems:"center", justifyContent: "center", height:50}}>2</TouchableOpacity>
          <TouchableOpacity onPress={()=>setNum2(3)} style={{padding: 10, backgroundColor: "#ccc", width:50, alignItems:"center", justifyContent: "center", height:50}}>3</TouchableOpacity>
          <TouchableOpacity onPress={()=>setNum2(4)} style={{padding: 10, backgroundColor: "#ccc", width:50, alignItems:"center", justifyContent: "center", height:50}}>4</TouchableOpacity>
          <TouchableOpacity onPress={()=>setNum2(5)} style={{padding: 10, backgroundColor: "#ccc", width:50, alignItems:"center", justifyContent: "center", height:50}}>5</TouchableOpacity>
          <TouchableOpacity onPress={()=>setNum2(6)} style={{padding: 10, backgroundColor: "#ccc", width:50, alignItems:"center", justifyContent: "center", height:50}}>6</TouchableOpacity>
          <TouchableOpacity onPress={()=>setNum2(7)} style={{padding: 10, backgroundColor: "#ccc", width:50, alignItems:"center", justifyContent: "center", height:50}}>7</TouchableOpacity>
          <TouchableOpacity onPress={()=>setNum2(8)} style={{padding: 10, backgroundColor: "#ccc", width:50, alignItems:"center", justifyContent: "center", height:50}}>8</TouchableOpacity>
          <TouchableOpacity onPress={()=>setNum2()} style={{padding: 10, backgroundColor: "#ccc", width:50, alignItems:"center", justifyContent: "center", height:50}}>9</TouchableOpacity>
          <TouchableOpacity onPress={()=>setNum2(0)} style={{padding: 10, backgroundColor: "#ccc", width:50, alignItems:"center", justifyContent: "center", height:50}}>0</TouchableOpacity>
        </View>

      </View>
      <View style={{flexDirection:"row", gap: 10}}>
        <TouchableOpacity onPress={Compute} style={{padding: 10, backgroundColor: "green", width:150, alignItems:"center", justifyContent: "center", height:50}}>Compute</TouchableOpacity>
      <TouchableOpacity onPress={Cancel} style={{padding: 10, backgroundColor: "red", width:50, alignItems:"center", justifyContent: "center", height:50}}>Xoa</TouchableOpacity>
      </View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    backgroundColor: '#ecf0f1',
    padding: 8,
  },
  paragraph: {
    margin: 24,
    fontSize: 18,
    fontWeight: 'bold',
    textAlign: 'center',
  },
});
