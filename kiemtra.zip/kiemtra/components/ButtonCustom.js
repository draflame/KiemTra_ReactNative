import { Text, SafeAreaView, StyleSheet, Image, View,TouchableOpacity, Linking } from 'react-native';
import {useState} from 'react'
// You can import supported modules from npm

const ButtonCustom=({txt, num1})=>{
  const [num, setNum]= useState(0)
   return(
      <SafeAreaView style={styles.container}>
      <TouchableOpacity onPress={()=>setNum(txt)} style={{padding: 10, backgroundColor: "#ccc", width:50, alignItems:"center", justifyContent: "center", height:50}}>{txt}</TouchableOpacity>
    </SafeAreaView>
   )
}
const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    backgroundColor: '#ecf0f1',
    padding: 8,
  },
  paragraph: {
    margin: 24,
    fontSize: 18,
    fontWeight: 'bold',
    textAlign: 'center',
  },
});
export default ButtonCustom